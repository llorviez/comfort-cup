# Comfort Cup — publishable web app prototype

A pink, mobile-friendly menstrual-cycle companion prototype based on the Comfort Cup concept.

## Included
- Period date logging and a monthly calendar
- Estimated next period based on a user-entered cycle length
- Cup fill-level demonstration (simulated; no sensor hardware)
- Cup-size preference, care guide, privacy screen
- Passphrase-based AES-GCM encryption for locally stored app data
- Encrypted backup export/import and delete-all control
- Basic PWA manifest, app icon, and offline service worker
- No third-party font or analytics dependency

## Run locally
Use a local web server (not `file://`), for example:
```bash
python -m http.server 8000
```
Then open `http://localhost:8000`. For real deployment, use HTTPS hosting.

## Publish
Upload the contents of this folder to a static hosting provider that supports HTTPS (for example GitHub Pages, Netlify, or Cloudflare Pages). Configure the published site to serve `index.html` at the site root. Test the deployed HTTPS URL on both Android and iOS browsers.

## Important limitations and safety
- This is a student prototype, not a clinically validated health product or medical device.
- The cup level is only a slider simulation. It is not connected to a physical sensor and must not guide cup emptying.
- Cycle predictions are estimates and can be inaccurate, especially with irregular cycles/PCOS. Actual period dates can be logged separately.
- No account, cloud sync, analytics, or server-side storage is implemented. Data is stored in the browser's IndexedDB and encrypted with a key derived from the user's passphrase using PBKDF2 and AES-GCM.
- Losing the passphrase means the encrypted data cannot be recovered. Browser data clearing can remove the records. Encrypted backups should be stored privately.
- Local encryption does not protect against a compromised device, malicious browser extensions, someone who knows the passphrase, or all forms of device-level access. This code has not had a professional security audit.
- Before public release, add a reviewed privacy notice, accessibility testing, cross-browser testing, security review, and a process for responding to user questions/incidents. If collecting real health information from the public, get appropriate legal/privacy advice for the jurisdictions where it will be offered.
- Do not describe this as “100% secure” or “100% perfect.” No app can guarantee that.
